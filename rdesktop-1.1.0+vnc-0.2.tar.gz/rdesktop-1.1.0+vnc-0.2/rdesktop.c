/*
   rdesktop: A Remote Desktop Protocol client.
   Entrypoint and utility functions
   Copyright (C) Matthew Chapman 1999-2001
   
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include <stdlib.h>		/* malloc realloc free */
#include <stdarg.h>		/* va_list va_start va_end */
#ifdef WIN32
#include "gnu/getopt.h"
#else
#include <unistd.h>		/* read close getuid getgid getpid getppid gethostname */
#include <sys/time.h>		/* gettimeofday */
#include <sys/times.h>		/* times */
#include <pwd.h>		/* getpwuid */
#endif
#include <fcntl.h>		/* open */
#include <sys/stat.h>		/* stat */
#include "rdesktop.h"

char username[16];
char hostname[16];
int width;
int height;
#ifdef RDP2VNC
#include <errno.h>
#ifndef WIN32
#include <sys/socket.h>
#else
#define HBITMAP R_HBITMAP
#define HCURSOR R_HCURSOR
#define WORD R_WORD
#include <winsock.h>
#undef HBITMAP
#undef HCURSOR
#undef WORD
#endif
extern int ListenOnTCPPort(int port);
extern int rfbClientSocket;
extern int rfb_port;
extern int defer_time;
int keylayout = 0;
#ifdef ENABLE_SHADOW
int client_counter = 0;
#endif
#else
BOOL general_keyboard = False;
BOOL vncviewer = False;
int keylayout = 0x409;
extern int keylayout_lookup(const int code);
extern void init_keycodes(const int id);
extern void workaround_Xvnc_keymap();
#endif
extern int keylayout_code_lookup(const char* short_key);
BOOL bitmap_compression = True;
BOOL sendmotion = True;
BOOL orders = True;
BOOL licence = True;
BOOL encryption = True;
BOOL desktop_save = True;
BOOL fullscreen = False;

/* Display usage information */
static void
usage(char *program)
{
	printf("Usage: %s [options] server\n", program);
#ifdef RDP2VNC
	printf("   -V: vnc port\n");
	printf("   -D: defer time (ms)\n");
#else
	printf("   -V: run inside Xvnc\n");
	printf("   -N: use general keyboard (non PC)\n");
#endif
	printf("   -u: user name\n");
	printf("   -d: domain\n");
	printf("   -s: shell\n");
	printf("   -c: working directory\n");
	printf("   -p: password (autologon)\n");
	printf("   -n: client hostname\n");
	printf("   -k: keyboard layout (hex)\n");
	printf("   -g: desktop geometry (WxH)\n");
	printf("   -f: full-screen mode\n");
	printf("   -b: force bitmap updates\n");
	printf("   -e: disable encryption (French TS)\n");
	printf("   -m: do not send motion events\n");
	printf("   -l: do not request licence\n\n");
}

/* Client program */
int
main(int argc, char *argv[])
{
	char fullhostname[64];
	char domain[16];
	char password[16];
	char shell[32];
	char directory[32];
	char title[32];
	struct passwd *pw;
	char *server, *p;
	uint32 flags;
	int c;

	printf("rdesktop: A Remote Desktop Protocol client.\n");
	printf("Version " VERSION ". Copyright (C) 1999-2001 Matt Chapman.\n");
	printf("See http://www.rdesktop.org/ for more information.\n\n");

	flags = RDP_LOGON_NORMAL;
	domain[0] = password[0] = shell[0] = directory[0] = 0;

#ifdef RDP2VNC
#define OPTIONSSTR "V:D:u:d:s:c:p:n:k:g:fbemlh?"
#else
#define OPTIONSSTR "VNu:d:s:c:p:n:k:g:fbemlh?"
#endif
	while ((c = getopt(argc, argv, OPTIONSSTR)) != -1)
	{
		switch (c)
		{
			case 'u':
				STRNCPY(username, optarg, sizeof(username));
				break;

			case 'd':
				STRNCPY(domain, optarg, sizeof(domain));
				break;

			case 's':
				STRNCPY(shell, optarg, sizeof(shell));
				break;

			case 'c':
				STRNCPY(directory, optarg, sizeof(directory));
				break;

			case 'p':
				STRNCPY(password, optarg, sizeof(password));
				flags |= RDP_LOGON_AUTO;
				break;

			case 'n':
				STRNCPY(hostname, optarg, sizeof(hostname));
				break;

#ifdef RDP2VNC
		        case 'V':
			        rfb_port = strtol(optarg,NULL,10);
				if(rfb_port<100) rfb_port += 5900;
				break;

		        case 'D':
			        defer_time = strtol(optarg,NULL,10);
				if(defer_time<0) defer_time = 0;
				break;

#else
			case 'V':
				vncviewer = True;
				general_keyboard = True;
				break;

			case 'N':
				general_keyboard = True;
				break;

#endif
			case 'k':
				if(optarg[0]>='0' && optarg[0]<='9')
					keylayout = strtol(optarg, NULL, 16);
				else
					keylayout = keylayout_code_lookup(optarg);
				break;

			case 'g':
				width = strtol(optarg, &p, 10);
				if (*p == 'x')
					height = strtol(p+1, NULL, 10);

				if ((width == 0) || (height == 0))
				{
					error("invalid geometry\n");
					return 1;
				}
				break;

			case 'f':
				fullscreen = True;
				break;

			case 'b':
				orders = False;
				break;

			case 'e':
				encryption = False;
				break;

			case 'm':
				sendmotion = False;
				break;

			case 'l':
				licence = False;
				break;

			case 'h':
			case '?':
			default:
				usage(argv[0]);
				return 1;
		}
	}

#ifndef RDP2VNC
	if(general_keyboard)
	{
		int id = keylayout_lookup(keylayout);
		init_keycodes(id);
	}

	if(vncviewer)
	{
		workaround_Xvnc_keymap();
	}

#endif
	if (argc - optind < 1)
	{
		usage(argv[0]);
		return 1;
	}

	server = argv[optind];

	if (username[0] == 0)
	{
#ifdef WIN32
		STRNCPY(username,"rdp2vnc",sizeof(username));
#else
		pw = getpwuid(getuid());
		if ((pw == NULL) || (pw->pw_name == NULL))
		{
			error("could not determine username, use -u\n");
			return 1;
		}

		STRNCPY(username, pw->pw_name, sizeof(username));
#endif
	}

	if (hostname[0] == 0)
	{
		if (gethostname(fullhostname, sizeof(fullhostname)) == -1)
		{
			error("could not determine local hostname, use -n\n");
			return 1;
		}

		p = strchr(fullhostname, '.');
		if (p != NULL)
			*p = 0;

		STRNCPY(hostname, fullhostname, sizeof(hostname));
	}

	if (!strcmp(password, "-"))
	{
#ifndef WIN32
		p = getpass("Password: ");
#endif
		if (p == NULL)
		{
			error("failed to read password\n");
			return 0;
		}
		STRNCPY(password, p, sizeof(password));
	}

	if ((width == 0) || (height == 0))
	{
		width = 800;
		height = 600;
	}

	strcpy(title, "rdesktop - ");
	strncat(title, server, sizeof(title) - sizeof("rdesktop - "));

#ifdef RDP2VNC
        {
	    struct sockaddr addr;
	    fd_set fdset;
	    struct timeval tv;
	    int rfbListenSock,addrlen=sizeof(addr);

	    rfbListenSock=ListenOnTCPPort(rfb_port);
	    fprintf(stderr,"Listening on VNC port %d\n",rfb_port);
	    if(rfbListenSock<=0)
	        error("Cannot listen on port %d",rfb_port);
	    else while(1) {
	        FD_ZERO(&fdset);
	        FD_SET(rfbListenSock,&fdset);
	        tv.tv_sec=5; tv.tv_usec=0;
	        if(select(rfbListenSock+1,&fdset,NULL,NULL,&tv)>0) {
#ifdef ENABLE_SHADOW
		  client_counter++;
#endif
#ifndef WIN32
		  // TODO !!!! Win32 has to have this command!
		  if (fork())
		    continue;
#endif
		  rfbClientSocket = accept(rfbListenSock,&addr,&addrlen);
		  if(rfbClientSocket<0) {
		    error("Error accepting client (%d: %s.\n",
			    errno,strerror(errno));
		    continue;
		  }
		  ui_create_window(title);
		  if(!rdp_connect(server, flags, domain, password,
				  shell, directory)) {
		    error("Error connecting to RDP server.\n");
		    continue;
		  }
		  printf("Connection successful.\n");
		  rdp_main_loop();
		  printf("Disconnecting...\n");
		  rdp_disconnect();
		  ui_destroy_window();
		  return(0);
		}
	    }
	}
#else
	if (ui_create_window(title))
	{
		if (!rdp_connect(server, flags, domain, password, shell,
				 directory))
			return 1;

		printf("Connection successful.\n");
		rdp_main_loop();
		printf("Disconnecting...\n");
		ui_destroy_window();
	}

	rdp_disconnect();
#endif
	return 0;
}

/* Generate a 32-byte random for the secure transport code. */
void
generate_random(uint8 *random)
{
	uint32 *r = (uint32 *) random;
#ifdef WIN32
	// This is weak crypto
	int i;
	srand(time());
	for(i=0;i<8;i++)
		r[0]=rand();
#else
	struct stat st;
	struct tms tmsbuf;
	int fd;

	/* If we have a kernel random device, use it. */
	if (((fd = open("/dev/urandom", O_RDONLY)) != -1)
	    || ((fd = open("/dev/random", O_RDONLY)) != -1))
	{
		read(fd, random, 32);
		close(fd);
		return;
	}

	/* Otherwise use whatever entropy we can gather - ideas welcome. */
	r[0] = (getpid()) | (getppid() << 16);
	r[1] = (getuid()) | (getgid() << 16);
	r[2] = times(&tmsbuf);	/* system uptime (clocks) */
	gettimeofday((struct timeval *) &r[3], NULL);	/* sec and usec */
	stat("/tmp", &st);
	r[5] = st.st_atime;
	r[6] = st.st_mtime;
	r[7] = st.st_ctime;
#endif
}

/* malloc; exit if out of memory */
void *
xmalloc(int size)
{
	void *mem = malloc(size);
	if (mem == NULL)
	{
		error("xmalloc %d\n", size);
		exit(1);
	}
	return mem;
}

/* realloc; exit if out of memory */
void *
xrealloc(void *oldmem, int size)
{
	void *mem = realloc(oldmem, size);
	if (mem == NULL)
	{
		error("xrealloc %d\n", size);
		exit(1);
	}
	return mem;
}

/* free */
void
xfree(void *mem)
{
	free(mem);
}

/* report an error */
void
error(char *format, ...)
{
	va_list ap;

	fprintf(stderr, "ERROR: ");

	va_start(ap, format);
	vfprintf(stderr, format, ap);
	va_end(ap);
}

/* report an unimplemented protocol feature */
void
unimpl(char *format, ...)
{
	va_list ap;

	fprintf(stderr, "NOT IMPLEMENTED: ");

	va_start(ap, format);
	vfprintf(stderr, format, ap);
	va_end(ap);
}

/* produce a hex dump */
void
hexdump(unsigned char *p, unsigned int len)
{
	unsigned char *line = p;
	unsigned int thisline, offset = 0;
	int i;

	while (offset < len)
	{
		printf("%04x ", offset);
		thisline = len - offset;
		if (thisline > 16)
			thisline = 16;

		for (i = 0; i < thisline; i++)
			printf("%02x ", line[i]);

		for (; i < 16; i++)
				printf("   ");

		for (i = 0; i < thisline; i++)
			printf("%c",
			       (line[i] >= 0x20
				&& line[i] < 0x7f) ? line[i] : '.');

		printf("\n");
		offset += thisline;
		line += thisline;
	}
}
